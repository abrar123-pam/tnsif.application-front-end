import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { InterviewComponent } from './interview/interview.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,InterviewComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'interviewApp';
}
