import { Component, OnInit } from '@angular/core';
import { Interview } from './interview';
import { InterviewService } from './interview.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-interview',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './interview.component.html',
  styleUrls: ['./interview.component.css']
})
export class InterviewComponent implements OnInit {
  interviews: Interview[] = [];
  formData: Interview = {
    applicationId: 0,
    interviewDate: '',
    interviewLocation: '',
    interviewResult: ''
  };
  showEditForm: boolean = false;

  constructor(private interviewService: InterviewService) { }

  ngOnInit(): void {
    this.getInterviews();
  }


  getInterviews(): void {
    this.interviewService.getAllInterviews().subscribe(
      interviews => this.interviews = interviews,
      error => console.error('Error fetching interviews:', error)
    );
  }

  onSubmit(): void {
    
      this.interviewService.addInterview(this.formData).subscribe(
          newInterview => {
            this.interviews.push(newInterview);
            this.formData = { interviewId: 0, applicationId: 0, interviewDate: '', interviewLocation: '', interviewResult: '' }; 
          },
          error => console.error('Error adding interview:', error)
        );
  }
  
  editInterview(interview: Interview) {
    this.formData = { ...interview }; 
    this.showEditForm = true;
  }

  onEditSubmit(): void {
    this.interviewService.updateInterview(this.formData.applicationId, this.formData)
      .subscribe(
        updatedInterview => {
          const index = this.interviews.findIndex(interview => interview.interviewId === updatedInterview.interviewId);
          if (index !== -1) {
            this.interviews[index] = updatedInterview;
          }
          this.showEditForm = false;
        },
        error => console.error('Error updating interview:', error)
      );
  }

  cancelEdit(): void {
    this.showEditForm = false;
  }

  deleteInterview(interviewId: number): void {
    this.interviewService.deleteInterview(interviewId)
      .subscribe(
        () => {
          this.interviews = this.interviews.filter(interview => interview.interviewId !== interviewId);
        },
        error => console.error('Error deleting interview:', error)
      );
  }

  
}
