export interface Interview {
    interviewId?:number;
    applicationId:number;
    interviewDate: string;
    interviewLocation:string;
    interviewResult:string;
}
