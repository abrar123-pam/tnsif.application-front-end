import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Interview } from './interview';

@Injectable({
  providedIn: 'root'
})

export class InterviewService {

  private baseUrl = 'http://localhost:8080'; 
  constructor(private http: HttpClient) { }

  getAllInterviews(): Observable<Interview[]> {
    return this.http.get<Interview[]>(`${this.baseUrl}/interview`);
  }

  getInterviewById(id: number): Observable<Interview> {
    return this.http.get<Interview>(`${this.baseUrl}/interview/${id}`);
  }

  addInterview(interview: Interview): Observable<Interview> {
    return this.http.post<Interview>("http://localhost:8080/interview", interview);
  }

  updateInterview(id: number, interview: Interview): Observable<Interview> {
    return this.http.put<Interview>(`${this.baseUrl}/interview/${id}`, interview);
  }

  deleteInterview(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/interview/${id}`);
  }
}
